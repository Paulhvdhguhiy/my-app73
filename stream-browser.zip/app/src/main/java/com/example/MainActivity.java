package com.example;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ExtensionsAdapter.OnExtensionClickListener, ExtensionsAdapter.OnExtensionDeleteListener {

    private DatabaseHelper dbHelper;
    private List<Extension> extensionList;
    private ExtensionsAdapter adapter;
    private RecyclerView recyclerView;
    private View textEmptyState;

    private EditText inputQuickUrl;
    private ImageButton btnQuickLoad;

    // View references for dynamic bottom tab switching
    private View containerTabHome;
    private View containerTabSaved;
    private View containerTabSettings;

    private View tabHome;
    private View tabSaved;
    private View tabSettings;

    private View tabHomeBg;
    private View tabSavedBg;
    private View tabSettingsBg;

    private ImageView tabHomeIcon;
    private ImageView tabSavedIcon;
    private ImageView tabSettingsIcon;

    private TextView tabHomeText;
    private TextView tabSavedText;
    private TextView tabSettingsText;

    private FloatingActionButton fabAdd;

    // State variables
    private boolean isVpnConnected = false;
    private String selectedServer = "Global Anycast (WARP Routing)";
    private String selectedProtocol = "Cloudflare WARP+";
    private String nodeIpAddress = "162.159.192.1";
    private int nodePingMs = 12;
    private String nodeSpeedRatio = "842 MB/s";
    
    // UI elements references
    private View containerTabVpn;
    private View tabVpn;
    private View tabVpnBg;
    private ImageView tabVpnIcon;
    private TextView tabVpnText;

    private TextView vpnStatusTitle;
    private View btnVpnToggle;
    private View vpnToggleInner;
    private ImageView vpnToggleIcon;
    private TextView vpnStatusSubtitle;
    private TextView vpnStatusIp;
    private TextView vpnStatPing;
    private TextView vpnStatSpeed;
    private TextView vpnStatSecuredData;
    private android.widget.RadioGroup radioGroupVpn;
    
    private ImageButton btnVoiceSearch;
    private static final int REQUEST_CODE_VOICE_SEARCH = 4224;

    private double simulatedTrafficGb = 4.12;
    private android.os.Handler trafficHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable trafficRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        extensionList = new ArrayList<>();

        // Core visual components
        recyclerView = findViewById(R.id.recycler_extensions);
        textEmptyState = findViewById(R.id.text_empty_state);
        fabAdd = findViewById(R.id.fab_add_extension);

        inputQuickUrl = findViewById(R.id.input_quick_url);
        btnQuickLoad = findViewById(R.id.btn_quick_load);
        btnVoiceSearch = findViewById(R.id.btn_voice_search);
        if (btnVoiceSearch != null) {
            btnVoiceSearch.setOnClickListener(v -> triggerVoiceSearch());
        }

        // Bind dynamic tab views
        containerTabHome = findViewById(R.id.container_tab_home);
        containerTabSaved = findViewById(R.id.container_tab_saved);
        containerTabSettings = findViewById(R.id.container_tab_settings);

        tabHome = findViewById(R.id.tab_home);
        tabSaved = findViewById(R.id.tab_saved);
        tabSettings = findViewById(R.id.tab_settings);

        tabHomeBg = findViewById(R.id.tab_home_bg);
        tabSavedBg = findViewById(R.id.tab_saved_bg);
        tabSettingsBg = findViewById(R.id.tab_settings_bg);

        tabHomeIcon = findViewById(R.id.tab_home_icon);
        tabSavedIcon = findViewById(R.id.tab_saved_icon);
        tabSettingsIcon = findViewById(R.id.tab_settings_icon);

        tabHomeText = findViewById(R.id.tab_home_text);
        tabSavedText = findViewById(R.id.tab_saved_text);
        tabSettingsText = findViewById(R.id.tab_settings_text);

        // Setup 2-column grid layout for Custom Saved Extensions Scroller
        if (recyclerView != null) {
            recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
            adapter = new ExtensionsAdapter(this, extensionList, this, this);
            recyclerView.setAdapter(adapter);
        }

        // Setup bottom tab clicks
        tabHome.setOnClickListener(v -> selectTab("home"));
        tabSaved.setOnClickListener(v -> selectTab("saved"));
        tabSettings.setOnClickListener(v -> selectTab("settings"));

        // Load extensions first
        loadExtensions();

        // Plus floating action button click
        if (fabAdd != null) {
            fabAdd.setOnClickListener(v -> showAddExtensionDialog());
        }

        // Setup quick load URL triggers
        if (btnQuickLoad != null) {
            btnQuickLoad.setOnClickListener(v -> triggerQuickLoad());
        }
        if (inputQuickUrl != null) {
            inputQuickUrl.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                    triggerQuickLoad();
                    return true;
                }
                return false;
            });
        }

        // Init and bind Popular Presets on the Home tab
        setupPopularPresets();

        // Setup Settings preferences control elements
        setupSettingsControls();

        // Init and bind WARP / VPN Controllers
        setupVpnControllers();

        // Default layout selection: HOME TAB FIRST
        selectTab("home");
    }

    private void selectTab(String tabName) {
        // Reset all bottom tab highlights to inactive slate colors
        if (tabHomeBg != null) tabHomeBg.setBackground(null);
        if (tabSavedBg != null) tabSavedBg.setBackground(null);
        if (tabVpnBg != null) tabVpnBg.setBackground(null);
        if (tabSettingsBg != null) tabSettingsBg.setBackground(null);

        if (tabHomeIcon != null) tabHomeIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#64748B")));
        if (tabSavedIcon != null) tabSavedIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#64748B")));
        if (tabVpnIcon != null) tabVpnIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#64748B")));
        if (tabSettingsIcon != null) tabSettingsIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#64748B")));

        if (tabHomeText != null) tabHomeText.setTextColor(Color.parseColor("#64748B"));
        if (tabSavedText != null) tabSavedText.setTextColor(Color.parseColor("#64748B"));
        if (tabVpnText != null) tabVpnText.setTextColor(Color.parseColor("#64748B"));
        if (tabSettingsText != null) tabSettingsText.setTextColor(Color.parseColor("#64748B"));

        // Hide all main containers
        if (containerTabHome != null) containerTabHome.setVisibility(View.GONE);
        if (containerTabSaved != null) containerTabSaved.setVisibility(View.GONE);
        if (containerTabVpn != null) containerTabVpn.setVisibility(View.GONE);
        if (containerTabSettings != null) containerTabSettings.setVisibility(View.GONE);
        if (fabAdd != null) fabAdd.setVisibility(View.GONE);

        // Transition layout view visibility structures
        if ("home".equals(tabName)) {
            if (tabHomeBg != null) {
                tabHomeBg.setBackgroundResource(R.drawable.shield_badge_bg);
                tabHomeBg.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#DBEAFE")));
            }
            if (tabHomeIcon != null) tabHomeIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#2563EB")));
            if (tabHomeText != null) tabHomeText.setTextColor(Color.parseColor("#2563EB"));
            if (containerTabHome != null) containerTabHome.setVisibility(View.VISIBLE);
        } else if ("saved".equals(tabName)) {
            if (tabSavedBg != null) {
                tabSavedBg.setBackgroundResource(R.drawable.shield_badge_bg);
                tabSavedBg.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#DBEAFE")));
            }
            if (tabSavedIcon != null) tabSavedIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#2563EB")));
            if (tabSavedText != null) tabSavedText.setTextColor(Color.parseColor("#2563EB"));
            if (containerTabSaved != null) containerTabSaved.setVisibility(View.VISIBLE);
            if (fabAdd != null) fabAdd.setVisibility(View.VISIBLE);
            loadExtensions(); // Refresh saved database items
        } else if ("vpn".equals(tabName)) {
            if (tabVpnBg != null) {
                tabVpnBg.setBackgroundResource(R.drawable.shield_badge_bg);
                tabVpnBg.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#DBEAFE")));
            }
            if (tabVpnIcon != null) tabVpnIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#2563EB")));
            if (tabVpnText != null) tabVpnText.setTextColor(Color.parseColor("#2563EB"));
            if (containerTabVpn != null) containerTabVpn.setVisibility(View.VISIBLE);
            updateServerSelectionUI();
        } else if ("settings".equals(tabName)) {
            if (tabSettingsBg != null) {
                tabSettingsBg.setBackgroundResource(R.drawable.shield_badge_bg);
                tabSettingsBg.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#DBEAFE")));
            }
            if (tabSettingsIcon != null) tabSettingsIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#2563EB")));
            if (tabSettingsText != null) tabSettingsText.setTextColor(Color.parseColor("#2563EB"));
            if (containerTabSettings != null) containerTabSettings.setVisibility(View.VISIBLE);
        }
    }

    private void setupPopularPresets() {
        // Preset 1: Youtube
        bindPreset(R.id.preset_youtube, "YouTube", "m.youtube.com", "Y", "#FEF2F2", "#EF4444", "https://m.youtube.com");
        // Preset 2: Vimeo
        bindPreset(R.id.preset_vimeo, "Vimeo", "vimeo.com/watch", "V", "#ECFEFF", "#06B6D4", "https://vimeo.com/watch");
        // Preset 3: Twitch
        bindPreset(R.id.preset_twitch, "Twitch", "m.twitch.tv", "T", "#F5F3FF", "#8B5CF6", "https://m.twitch.tv");
        // Preset 4: Dailymotion
        bindPreset(R.id.preset_dailymotion, "Dailymotion", "dailymotion.com", "D", "#FFFBEB", "#F59E0B", "https://www.dailymotion.com");
    }

    private void bindPreset(int presetId, String nameVal, String urlVal, String letterVal, String softBgHex, String boldHex, String destinationUrl) {
        View presetView = findViewById(presetId);
        if (presetView != null) {
            TextView name = presetView.findViewById(R.id.preset_name);
            TextView url = presetView.findViewById(R.id.preset_url);
            TextView letter = presetView.findViewById(R.id.preset_icon_letter);
            View iconBg = presetView.findViewById(R.id.preset_icon_bg);
            View shape = presetView.findViewById(R.id.preset_shape);

            if (name != null) name.setText(nameVal);
            if (url != null) url.setText(urlVal);
            if (letter != null) letter.setText(letterVal);

            if (iconBg != null && iconBg.getBackground() instanceof GradientDrawable) {
                ((GradientDrawable) iconBg.getBackground()).setColor(Color.parseColor(softBgHex));
            }
            if (shape != null && shape.getBackground() instanceof GradientDrawable) {
                ((GradientDrawable) shape.getBackground()).setColor(Color.parseColor(boldHex));
            }

            presetView.setOnClickListener(v -> {
                Intent intent = new Intent(this, BrowserActivity.class);
                intent.putExtra("title", nameVal);
                intent.putExtra("url", destinationUrl);
                startActivity(intent);
            });
        }
    }

    private void setupSettingsControls() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

        // 1. Adblock active toggle
        androidx.appcompat.widget.SwitchCompat switchAdblock = findViewById(R.id.switch_adblock);
        if (switchAdblock != null) {
            switchAdblock.setChecked(prefs.getBoolean("ad_block_enabled", true));
            switchAdblock.setOnCheckedChangeListener((buttonView, isChecked) -> {
                prefs.edit().putBoolean("ad_block_enabled", isChecked).apply();
                Toast.makeText(this, isChecked ? "Adblock Shield Enabled" : "Adblock Shield Disabled", Toast.LENGTH_SHORT).show();
            });
        }

        // 2. Desktop Mode user agent toggle
        androidx.appcompat.widget.SwitchCompat switchDesktop = findViewById(R.id.switch_desktop_mode);
        if (switchDesktop != null) {
            switchDesktop.setChecked(prefs.getBoolean("desktop_mode_enabled", false));
            switchDesktop.setOnCheckedChangeListener((buttonView, isChecked) -> {
                prefs.edit().putBoolean("desktop_mode_enabled", isChecked).apply();
                Toast.makeText(this, isChecked ? "Desktop Engine Mode Enabled" : "Desktop Engine Mode Disabled", Toast.LENGTH_SHORT).show();
            });
        }

        // 3. Voice search language selection
        View cardVoiceLang = findViewById(R.id.card_voice_language);
        TextView textSelectedVoiceLang = findViewById(R.id.text_selected_voice_language);
        
        final String[] languages = {
            "System Default Locale",
            "English (United States)",
            "Español (España/Latam)",
            "Français (France)",
            "Deutsch (Deutschland)",
            "हिन्दी (India)",
            "日本語 (日本)",
            "中文 (简体/繁体)",
            "Português (Brasil)",
            "Русский (Россия)",
            "العربية (Arab World)",
            "বাংলা (Bangladesh/India)"
        };
        
        final String[] languageCodes = {
            "default",
            "en-US",
            "es-ES",
            "fr-FR",
            "de-DE",
            "hi-IN",
            "ja-JP",
            "zh-CN",
            "pt-BR",
            "ru-RU",
            "ar",
            "bn-BD"
        };
        
        if (textSelectedVoiceLang != null) {
            String savedCode = prefs.getString("voice_language_code", "default");
            int selectedIndex = 0;
            for (int i = 0; i < languageCodes.length; i++) {
                if (languageCodes[i].equals(savedCode)) {
                    selectedIndex = i;
                    break;
                }
            }
            textSelectedVoiceLang.setText(languages[selectedIndex]);
        }
        
        if (cardVoiceLang != null) {
            cardVoiceLang.setOnClickListener(v -> {
                String savedCode = prefs.getString("voice_language_code", "default");
                int selectedIndex = 0;
                for (int i = 0; i < languageCodes.length; i++) {
                    if (languageCodes[i].equals(savedCode)) {
                        selectedIndex = i;
                        break;
                    }
                }
                
                new MaterialAlertDialogBuilder(this)
                    .setTitle("Select Voice Search Language")
                    .setSingleChoiceItems(languages, selectedIndex, (dialog, which) -> {
                        prefs.edit().putString("voice_language_code", languageCodes[which]).apply();
                        if (textSelectedVoiceLang != null) {
                            textSelectedVoiceLang.setText(languages[which]);
                        }
                        Toast.makeText(this, "Voice Language set to: " + languages[which], Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            });
        }

        // 3. Delete all Custom shortcuts locally
        Button btnClear = findViewById(R.id.btn_clear_data);
        if (btnClear != null) {
            btnClear.setOnClickListener(v -> {
                new MaterialAlertDialogBuilder(this)
                        .setTitle("Delete Custom Shortcuts")
                        .setMessage("Are you sure you want to permanently clear all custom streaming shortcuts from your database helpers?")
                        .setPositiveButton("Erase All", (dialog, which) -> {
                            try {
                                if (dbHelper != null) {
                                    List<Extension> all = dbHelper.getAllExtensions();
                                    for (Extension ext : all) {
                                        dbHelper.deleteExtension(ext.getId());
                                    }
                                    Toast.makeText(this, "All database custom extensions cleared successfully!", Toast.LENGTH_SHORT).show();
                                    loadExtensions();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            });
        }
    }

    private void triggerQuickLoad() {
        try {
            if (inputQuickUrl == null) return;
            String userInput = inputQuickUrl.getText().toString().trim();
            if (userInput.isEmpty()) {
                Toast.makeText(this, "Please enter a stream URL or search query first!", Toast.LENGTH_SHORT).show();
                return;
            }

            String url;
            boolean isUrl = false;
            // A simple check to see if it's a domain/URL or search query:
            // Must not contain spaces, and must either have http/https prefix or match the WEB_URL pattern
            if (!userInput.contains(" ")) {
                if (userInput.startsWith("http://") || userInput.startsWith("https://")) {
                    isUrl = true;
                } else {
                    isUrl = android.util.Patterns.WEB_URL.matcher(userInput).matches();
                }
            }

            if (isUrl) {
                url = userInput;
                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                    url = "https://" + url;
                }
            } else {
                // If it's a query or name, route to Google search engine
                String query = java.net.URLEncoder.encode(userInput, "UTF-8");
                url = "https://www.google.com/search?q=" + query;
            }

            Intent intent = new Intent(this, BrowserActivity.class);
            intent.putExtra("title", isUrl ? "Quick Stream" : "Search: " + userInput);
            intent.putExtra("url", url);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Unable to load stream browser", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadExtensions() {
        try {
            if (extensionList == null || dbHelper == null || adapter == null) return;
            extensionList.clear();
            List<Extension> dbList = dbHelper.getAllExtensions();
            if (dbList != null) {
                extensionList.addAll(dbList);
            }
            adapter.notifyDataSetChanged();

            if (textEmptyState != null && recyclerView != null) {
                if (extensionList.isEmpty()) {
                    textEmptyState.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                } else {
                    textEmptyState.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAddExtensionDialog() {
        try {
            View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_extension, null);
            if (dialogView == null) return;
            EditText inputName = dialogView.findViewById(R.id.input_extension_name);
            EditText inputUrl = dialogView.findViewById(R.id.input_extension_url);

            new MaterialAlertDialogBuilder(this)
                    .setTitle("Add Streaming Extension")
                    .setMessage("Add a name and website link for your video streaming platform.")
                    .setView(dialogView)
                    .setPositiveButton("Save", (dialog, which) -> {
                        try {
                            if (inputName == null || inputUrl == null) return;
                            String name = inputName.getText().toString().trim();
                            String url = inputUrl.getText().toString().trim();

                            if (name.isEmpty() || url.isEmpty()) {
                                Toast.makeText(this, "Fields cannot be empty!", Toast.LENGTH_SHORT).show();
                                return;
                            }

                            // Strict auto-formatting of standard urls
                            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                                url = "https://" + url;
                            }

                            if (dbHelper != null) {
                                long id = dbHelper.addExtension(name, url);
                                if (id > 0) {
                                    Toast.makeText(this, "Extension added successfully!", Toast.LENGTH_SHORT).show();
                                    loadExtensions();
                                } else {
                                    Toast.makeText(this, "Error adding entry", Toast.LENGTH_SHORT).show();
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onExtensionClick(Extension extension) {
        try {
            if (extension == null) return;
            // Launch optimized streaming browser wrapper
            Intent intent = new Intent(this, BrowserActivity.class);
            intent.putExtra("title", extension.getName());
            intent.putExtra("url", extension.getUrl());
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Unable to launch stream", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onExtensionDelete(Extension extension, int position) {
        try {
            if (extension == null) return;
            new MaterialAlertDialogBuilder(this)
                    .setTitle("Delete Extension")
                    .setMessage("Are you sure you want to remove '" + extension.getName() + "'?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        try {
                            if (dbHelper != null) {
                                dbHelper.deleteExtension(extension.getId());
                                Toast.makeText(this, "Removed successfully", Toast.LENGTH_SHORT).show();
                                loadExtensions();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    })
                    .setNegativeButton("Keep", null)
                    .show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupVpnControllers() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        isVpnConnected = prefs.getBoolean("vpn_shield_enabled", false);
        selectedServer = prefs.getString("vpn_selected_server", "Global Anycast (WARP Routing)");
        selectedProtocol = prefs.getString("vpn_selected_protocol", "Cloudflare WARP+");
        nodeIpAddress = prefs.getString("vpn_node_ip", "162.159.192.1");
        nodePingMs = prefs.getInt("vpn_node_ping", 12);
        nodeSpeedRatio = prefs.getString("vpn_node_speed", "842 MB/s");

        // Bind layout views
        containerTabVpn = findViewById(R.id.container_tab_vpn);
        tabVpn = findViewById(R.id.tab_vpn);
        tabVpnBg = findViewById(R.id.tab_vpn_bg);
        tabVpnIcon = findViewById(R.id.tab_vpn_icon);
        tabVpnText = findViewById(R.id.tab_vpn_text);

        vpnStatusTitle = findViewById(R.id.vpn_status_title);
        btnVpnToggle = findViewById(R.id.btn_vpn_toggle);
        vpnToggleInner = findViewById(R.id.vpn_toggle_inner);
        vpnToggleIcon = findViewById(R.id.vpn_toggle_icon);
        vpnStatusSubtitle = findViewById(R.id.vpn_status_subtitle);
        vpnStatusIp = findViewById(R.id.vpn_status_ip);
        vpnStatPing = findViewById(R.id.vpn_stat_ping);
        vpnStatSpeed = findViewById(R.id.vpn_stat_speed);
        vpnStatSecuredData = findViewById(R.id.vpn_stat_secured_kb);
        radioGroupVpn = findViewById(R.id.radio_group_vpn);

        // Server rows click triggers
        setupServerRow(R.id.server_anycast, "Global Anycast (WARP Routing)", "Latency: 12ms • Anycast Node Enabled", "🌐", "162.159.192.1", 12, "842 MB/s");
        setupServerRow(R.id.server_us, "United States (Miami Boost)", "Latency: 45ms • High Speed Stream", "🇺🇸", "104.244.42.1", 45, "620 MB/s");
        setupServerRow(R.id.server_de, "Germany (Frankfurt Node)", "Latency: 28ms • Secure Media Router", "🇩🇪", "109.250.60.25", 28, "510 MB/s");
        setupServerRow(R.id.server_sg, "Singapore (Changi Media)", "Latency: 32ms • Zero-BufferSize Node", "🇸🇬", "210.14.88.19", 32, "480 MB/s");
        setupServerRow(R.id.server_jp, "Japan (Tokyo Hub)", "Latency: 22ms • HD Acceleration Stream", "🇯🇵", "122.211.45.16", 22, "590 MB/s");
        setupServerRow(R.id.server_uk, "United Kingdom (London Stream)", "Latency: 38ms • Ad-Stripper Proxy Hub", "🇬🇧", "195.154.122.9", 38, "430 MB/s");

        // Protocol radio triggers
        if (radioGroupVpn != null) {
            // Set initial state based on string value
            if ("Cloudflare WARP+".equals(selectedProtocol)) {
                radioGroupVpn.check(R.id.radio_protocol_warp);
            } else if ("VPN - WireGuard".equals(selectedProtocol)) {
                radioGroupVpn.check(R.id.radio_protocol_wireguard);
            } else if ("VPN - OpenVPN".equals(selectedProtocol)) {
                radioGroupVpn.check(R.id.radio_protocol_openvpn);
            } else if ("VPN - Shadowsocks".equals(selectedProtocol)) {
                radioGroupVpn.check(R.id.radio_protocol_shadowsocks);
            }

            radioGroupVpn.setOnCheckedChangeListener((group, checkedId) -> {
                String proto = "Cloudflare WARP+";
                if (checkedId == R.id.radio_protocol_warp) {
                    proto = "Cloudflare WARP+";
                } else if (checkedId == R.id.radio_protocol_wireguard) {
                    proto = "VPN - WireGuard";
                } else if (checkedId == R.id.radio_protocol_openvpn) {
                    proto = "VPN - OpenVPN";
                } else if (checkedId == R.id.radio_protocol_shadowsocks) {
                    proto = "VPN - Shadowsocks";
                }
                selectedProtocol = proto;
                prefs.edit().putString("vpn_selected_protocol", proto).apply();
                Toast.makeText(this, "Protocol changed to: " + proto, Toast.LENGTH_SHORT).show();
                
                // Hot restart connection with new encryption profile if connected
                if (isVpnConnected) {
                    triggerVpnDisconnect();
                    triggerVpnConnect();
                }
            });
        }

        // Connect/Disconnect button listener
        if (btnVpnToggle != null) {
            btnVpnToggle.setOnClickListener(v -> {
                triggerVpnToggle();
            });
        }

        // Setup bottom tab clicks additional triggers for tabVpn
        if (tabVpn != null) {
            tabVpn.setOnClickListener(v -> selectTab("vpn"));
        }

        // Set initial UI states
        updateVpnConnectionUI();
        updateServerSelectionUI();

        // Simulated continuous data flow thread when connected
        try {
            simulatedTrafficGb = Double.parseDouble(prefs.getString("vpn_simulated_traffic", "4.120"));
        } catch (Exception e) {
            simulatedTrafficGb = 4.120;
        }
        trafficRunnable = new Runnable() {
            @Override
            public void run() {
                if (isVpnConnected) {
                    simulatedTrafficGb += 0.002 + Math.random() * 0.008;
                    if (vpnStatSecuredData != null) {
                        vpnStatSecuredData.setText(String.format(java.util.Locale.US, "%.3f GB", simulatedTrafficGb));
                    }
                    prefs.edit().putString("vpn_simulated_traffic", String.valueOf(simulatedTrafficGb)).apply();
                }
                trafficHandler.postDelayed(this, 2000);
            }
        };
        trafficHandler.postDelayed(trafficRunnable, 2000);
    }

    private void setupServerRow(int rowId, String name, String details, String flag, String ip, int ping, String speed) {
        View row = findViewById(rowId);
        if (row != null) {
            TextView flagText = row.findViewById(R.id.server_flag_icon);
            TextView nameText = row.findViewById(R.id.server_name);
            TextView detailsText = row.findViewById(R.id.server_details);

            if (flagText != null) flagText.setText(flag);
            if (nameText != null) nameText.setText(name);
            if (detailsText != null) detailsText.setText(details);

            row.setOnClickListener(v -> {
                selectedServer = name;
                nodeIpAddress = ip;
                nodePingMs = ping;
                nodeSpeedRatio = speed;

                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
                prefs.edit()
                     .putString("vpn_selected_server", name)
                     .putString("vpn_node_ip", ip)
                     .putInt("vpn_node_ping", ping)
                     .putString("vpn_node_speed", speed)
                     .apply();

                updateServerSelectionUI();
                Toast.makeText(this, "Selected Node: " + name, Toast.LENGTH_SHORT).show();

                if (isVpnConnected) {
                    // Simulate hot reconnect to selected server
                    triggerVpnDisconnect();
                    triggerVpnConnect();
                } else {
                    updateVpnConnectionUI();
                }
            });
        }
    }

    private void triggerVpnToggle() {
        if (isVpnConnected) {
            triggerVpnDisconnect();
        } else {
            triggerVpnConnect();
        }
    }

    private void triggerVpnConnect() {
        if (vpnStatusTitle != null) vpnStatusTitle.setText("STATUS: SECURING HANDSHAKE...");
        if (vpnStatusSubtitle != null) vpnStatusSubtitle.setText("Negotiating key exchange...");
        if (btnVpnToggle != null) {
            btnVpnToggle.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#F59E0B"))); // Amber connecting
        }
        if (vpnToggleInner != null) {
            vpnToggleInner.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#D97706")));
        }

        // Simulate secure handshake latency animation
        if (btnVpnToggle != null) {
            btnVpnToggle.setEnabled(false);
        }
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            isVpnConnected = true;
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
            prefs.edit().putBoolean("vpn_shield_enabled", true).apply();
            
            updateVpnConnectionUI();
            if (btnVpnToggle != null) btnVpnToggle.setEnabled(true);
            Toast.makeText(MainActivity.this, "Active Shield: " + selectedProtocol + " Connected via " + selectedServer, Toast.LENGTH_LONG).show();
            
            // Also notify and update the main adshield indicator banner on top if visible!
            updateAdblockBannerState();
        }, 1200);
    }

    private void triggerVpnDisconnect() {
        isVpnConnected = false;
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        prefs.edit().putBoolean("vpn_shield_enabled", false).apply();
        updateVpnConnectionUI();
        Toast.makeText(this, "Active Shield Disconnected", Toast.LENGTH_SHORT).show();
        updateAdblockBannerState();
    }

    private void updateVpnConnectionUI() {
        if (btnVpnToggle == null || vpnStatusTitle == null || vpnStatusSubtitle == null || vpnStatusIp == null) return;

        if (isVpnConnected) {
            // Connected green state
            vpnStatusTitle.setText("STATUS: SHIELD ENCRYPTION ACTIVE");
            vpnStatusTitle.setTextColor(Color.parseColor("#10B981"));
            
            btnVpnToggle.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#10B981"))); // Emerald green
            if (vpnToggleInner != null) {
                vpnToggleInner.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#059669")));
            }
            if (vpnToggleIcon != null) {
                vpnToggleIcon.setImageResource(android.R.drawable.ic_lock_lock);
                vpnToggleIcon.setImageTintList(ColorStateList.valueOf(Color.WHITE));
            }
            
            vpnStatusSubtitle.setText(selectedProtocol + " Connected");
            vpnStatusSubtitle.setTextColor(Color.parseColor("#059669"));
            
            vpnStatusIp.setText("Protected Tunnel IP: " + nodeIpAddress);
            vpnStatusIp.setTextColor(Color.parseColor("#047857"));

            if (vpnStatPing != null) {
                vpnStatPing.setText(nodePingMs + " ms");
                vpnStatPing.setTextColor(Color.parseColor("#10B981"));
            }
            if (vpnStatSpeed != null) {
                vpnStatSpeed.setText(nodeSpeedRatio);
                vpnStatSpeed.setTextColor(Color.parseColor("#10B981"));
            }
            if (vpnStatSecuredData != null) {
                vpnStatSecuredData.setText(String.format(java.util.Locale.US, "%.3f GB", simulatedTrafficGb));
            }
        } else {
            // Disconnected gray state
            vpnStatusTitle.setText("STATUS: SHIELD ENCRYPTION OFF");
            vpnStatusTitle.setTextColor(Color.parseColor("#64748B"));
            
            btnVpnToggle.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#64748B"))); // Slate gray
            if (vpnToggleInner != null) {
                vpnToggleInner.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#475569")));
            }
            if (vpnToggleIcon != null) {
                vpnToggleIcon.setImageResource(android.R.drawable.ic_lock_idle_lock);
                vpnToggleIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#B4C6E7")));
            }
            
            vpnStatusSubtitle.setText("Tap to secure your connection");
            vpnStatusSubtitle.setTextColor(Color.parseColor("#334155"));
            
            vpnStatusIp.setText("IP: --.--.--.-- (Anonymized)");
            vpnStatusIp.setTextColor(Color.parseColor("#64748B"));

            if (vpnStatPing != null) {
                vpnStatPing.setText("-- ms");
                vpnStatPing.setTextColor(Color.parseColor("#64748B"));
            }
            if (vpnStatSpeed != null) {
                vpnStatSpeed.setText("-- MB/s");
                vpnStatSpeed.setTextColor(Color.parseColor("#64748B"));
            }
        }
    }

    private void updateServerSelectionUI() {
        int[] rowIds = {
            R.id.server_anycast, R.id.server_us, R.id.server_de, 
            R.id.server_sg, R.id.server_jp, R.id.server_uk
        };
        String[] names = {
            "Global Anycast (WARP Routing)", "United States (Miami Boost)", "Germany (Frankfurt Node)", 
            "Singapore (Changi Media)", "Japan (Tokyo Hub)", "United Kingdom (London Stream)"
        };

        for (int i = 0; i < rowIds.length; i++) {
            View rowView = findViewById(rowIds[i]);
            if (rowView != null) {
                ImageView checkedIcon = rowView.findViewById(R.id.server_checked_icon);
                View cardBg = rowView;
                if (checkedIcon != null) {
                    if (names[i].equals(selectedServer)) {
                        checkedIcon.setImageResource(android.R.drawable.presence_online);
                        checkedIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#2563EB")));
                        if (cardBg instanceof com.google.android.material.card.MaterialCardView) {
                            ((com.google.android.material.card.MaterialCardView) cardBg).setStrokeColor(Color.parseColor("#2563EB"));
                            ((com.google.android.material.card.MaterialCardView) cardBg).setStrokeWidth(3);
                        }
                    } else {
                        checkedIcon.setImageResource(android.R.drawable.presence_invisible);
                        checkedIcon.setImageTintList(ColorStateList.valueOf(Color.parseColor("#64748B")));
                        if (cardBg instanceof com.google.android.material.card.MaterialCardView) {
                            ((com.google.android.material.card.MaterialCardView) cardBg).setStrokeColor(Color.parseColor("#F1F5F9"));
                            ((com.google.android.material.card.MaterialCardView) cardBg).setStrokeWidth(2);
                        }
                    }
                }
            }
        }
    }

    private void updateAdblockBannerState() {
        RelativeLayout banner = findViewById(R.id.banner_adblocker);
        if (banner != null) {
            TextView bannerText = null;
            for (int i = 0; i < banner.getChildCount(); i++) {
                View child = banner.getChildAt(i);
                if (child instanceof TextView) {
                    TextView tv = (TextView) child;
                    if (tv.getText().toString().contains("Ad-Shield") || tv.getText().toString().contains("Shield Active") || tv.getText().toString().contains("Protected") || tv.getText().toString().contains("Ad-blocker")) {
                        bannerText = tv;
                        break;
                    }
                }
            }

            if (isVpnConnected) {
                if (bannerText != null) {
                    String cleanName = selectedServer.split(" ")[0].trim();
                     bannerText.setText("Secured: " + selectedProtocol + " [" + cleanName + "]");
                }
            } else {
                if (bannerText != null) {
                    bannerText.setText("Ad-Shield Core Engine Active");
                }
            }
        }
    }

    private void triggerVoiceSearch() {
        try {
            Intent intent = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
            String langCode = prefs.getString("voice_language_code", "default");
            if (!"default".equals(langCode)) {
                intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, langCode);
                intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langCode);
                intent.putExtra(android.speech.RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, langCode);
            } else {
                intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, java.util.Locale.getDefault().toString());
            }
            
            intent.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak now to search...");
            startActivityForResult(intent, REQUEST_CODE_VOICE_SEARCH);
        } catch (android.content.ActivityNotFoundException e) {
            Toast.makeText(this, "Voice Speech Recognition is not supported on this device.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_VOICE_SEARCH && resultCode == RESULT_OK && data != null) {
            java.util.ArrayList<String> results = data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String spokenText = results.get(0);
                if (inputQuickUrl != null) {
                    inputQuickUrl.setText(spokenText);
                    triggerQuickLoad();
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (trafficHandler != null && trafficRunnable != null) {
            trafficHandler.removeCallbacks(trafficRunnable);
        }
        super.onDestroy();
    }
}
