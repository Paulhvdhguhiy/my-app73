package com.example;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

public class ExtensionsAdapter extends RecyclerView.Adapter<ExtensionsAdapter.ViewHolder> {

    private final Context context;
    private final List<Extension> extensionList;
    private final OnExtensionClickListener clickListener;
    private final OnExtensionDeleteListener deleteListener;

    public interface OnExtensionClickListener {
        void onExtensionClick(Extension extension);
    }

    public interface OnExtensionDeleteListener {
        void onExtensionDelete(Extension extension, int position);
    }

    public ExtensionsAdapter(Context context, List<Extension> extensionList,
                             OnExtensionClickListener clickListener, OnExtensionDeleteListener deleteListener) {
        this.context = context;
        this.extensionList = extensionList;
        this.clickListener = clickListener;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_extension, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Extension ext = extensionList.get(position);
        holder.textName.setText(ext.getName());

        // Display simplified clean Hostname instead of full URL
        String host = ext.getUrl();
        try {
            URI uri = new URI(ext.getUrl());
            String extractedHost = uri.getHost();
            if (extractedHost != null) {
                host = extractedHost.replace("www.", "").replace("m.", "");
            }
        } catch (URISyntaxException e) {
            // Fallback to URL
        }
        holder.textUrl.setText(host);

        // Hide literal text character to match the visual Geometric Balance model
        holder.textIconLetter.setVisibility(View.GONE);

        // Reset all shape visibilities
        holder.shapeSquare.setVisibility(View.GONE);
        holder.shapePill.setVisibility(View.GONE);
        holder.shapeRing.setVisibility(View.GONE);
        holder.shapeBar.setVisibility(View.GONE);

        // Map positions to Tailwind balanced design presets
        int scheme = position % 4;
        String softBgColor;
        String accentColor;

        switch (scheme) {
            case 0:
                softBgColor = "#FEF2F2"; // Soft Red
                accentColor = "#EF4444"; // Bold Red
                holder.shapeSquare.setVisibility(View.VISIBLE);
                holder.shapeSquare.setRotation(45f);
                if (holder.shapeSquare.getBackground() instanceof GradientDrawable) {
                    GradientDrawable sqBg = (GradientDrawable) holder.shapeSquare.getBackground();
                    sqBg.setColor(Color.parseColor(accentColor));
                }
                break;
            case 1:
                softBgColor = "#ECFDF5"; // Soft Emerald
                accentColor = "#10B981"; // Bold Emerald
                holder.shapePill.setVisibility(View.VISIBLE);
                if (holder.shapePill.getBackground() instanceof GradientDrawable) {
                    GradientDrawable pillBg = (GradientDrawable) holder.shapePill.getBackground();
                    pillBg.setColor(Color.parseColor(accentColor));
                }
                break;
            case 2:
                softBgColor = "#FFFBEB"; // Soft Amber
                accentColor = "#F59E0B"; // Bold Amber
                holder.shapeRing.setVisibility(View.VISIBLE);
                if (holder.shapeRing.getBackground() instanceof GradientDrawable) {
                    GradientDrawable ringBg = (GradientDrawable) holder.shapeRing.getBackground();
                    ringBg.setColor(Color.TRANSPARENT);
                    ringBg.setStroke((int)(3 * context.getResources().getDisplayMetrics().density), Color.parseColor(accentColor));
                }
                break;
            case 3:
            default:
                softBgColor = "#EEF2FF"; // Soft Indigo
                accentColor = "#6366F1"; // Bold Indigo
                holder.shapeBar.setVisibility(View.VISIBLE);
                if (holder.shapeBar.getBackground() instanceof GradientDrawable) {
                    GradientDrawable barBg = (GradientDrawable) holder.shapeBar.getBackground();
                    barBg.setColor(Color.parseColor(accentColor));
                }
                break;
        }

        // Apply soft pastel rounded background
        Object iconBgDrawable = holder.viewIconBg.getBackground();
        if (iconBgDrawable instanceof GradientDrawable) {
            ((GradientDrawable) iconBgDrawable).setColor(Color.parseColor(softBgColor));
        }

        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onExtensionClick(ext);
            }
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onExtensionDelete(ext, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return extensionList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textName;
        public TextView textUrl;
        public View viewIconBg;
        public TextView textIconLetter;
        public ImageButton btnDelete;

        // Custom geometric inner shapes
        public View shapeSquare;
        public View shapePill;
        public View shapeRing;
        public View shapeBar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.text_name);
            textUrl = itemView.findViewById(R.id.text_url);
            viewIconBg = itemView.findViewById(R.id.view_icon_bg);
            textIconLetter = itemView.findViewById(R.id.text_icon_letter);
            btnDelete = itemView.findViewById(R.id.btn_delete);

            shapeSquare = itemView.findViewById(R.id.shape_square);
            shapePill = itemView.findViewById(R.id.shape_pill);
            shapeRing = itemView.findViewById(R.id.shape_ring);
            shapeBar = itemView.findViewById(R.id.shape_bar);
        }
    }
}
