package com.example;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.Set;

public class BrowserActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressBar progressBar;
    private FrameLayout fullscreenContainer;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private CustomWebChromeClient chromeClient;

    private TextView textTitle;
    private ImageButton btnBack;
    private ImageButton btnRefresh;
    private View toolbar;

    // Direct memory static list for super-fast ad/tracker lookup constant complexity checks
    private static final Set<String> AD_KEYWORDS = new HashSet<>();
    static {
        AD_KEYWORDS.add("doubleclick");
        AD_KEYWORDS.add("googleads");
        AD_KEYWORDS.add("googlesyndication");
        AD_KEYWORDS.add("adservice");
        AD_KEYWORDS.add("adnxs");
        AD_KEYWORDS.add("pubads");
        AD_KEYWORDS.add("popads");
        AD_KEYWORDS.add("onclickads");
        AD_KEYWORDS.add("exoclick");
        AD_KEYWORDS.add("adsterra");
        AD_KEYWORDS.add("a-ads");
        AD_KEYWORDS.add("mgid");
        AD_KEYWORDS.add("zedo");
        AD_KEYWORDS.add("popunder");
        AD_KEYWORDS.add("outbrain");
        AD_KEYWORDS.add("taboola");
        AD_KEYWORDS.add("adroll");
        AD_KEYWORDS.add("adcolony");
        AD_KEYWORDS.add("chartboost");
        AD_KEYWORDS.add("vungle");
        AD_KEYWORDS.add("applovin");
        AD_KEYWORDS.add("pagead");
        AD_KEYWORDS.add("moatads");
        AD_KEYWORDS.add("scorecardresearch");
        AD_KEYWORDS.add("adskeeper");
        AD_KEYWORDS.add("coinhive");
        AD_KEYWORDS.add("trafficjunky");
        AD_KEYWORDS.add("juicyads");
        AD_KEYWORDS.add("ero-advertising");
        AD_KEYWORDS.add("propellerads");
        AD_KEYWORDS.add("ad-delivery");
        AD_KEYWORDS.add("banner");
        AD_KEYWORDS.add("adserver");
        AD_KEYWORDS.add("addthis");
        AD_KEYWORDS.add("anyclip");
        AD_KEYWORDS.add("adnxs");
        AD_KEYWORDS.add("popcash");
        AD_KEYWORDS.add("dynamicyield");
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);

        // Core interactive widget bindings
        webView = findViewById(R.id.webview);
        progressBar = findViewById(R.id.progress_bar);
        fullscreenContainer = findViewById(R.id.fullscreen_container);
        toolbar = findViewById(R.id.browser_toolbar);
        textTitle = findViewById(R.id.text_browser_title);
        btnBack = findViewById(R.id.btn_browser_back);
        btnRefresh = findViewById(R.id.btn_browser_refresh);

        String title = getIntent().getStringExtra("title");
        String url = getIntent().getStringExtra("url");

        if (title != null) {
            textTitle.setText(title);
        } else {
            textTitle.setText(R.string.app_name);
        }

        btnBack.setOnClickListener(v -> onBackPressed());
        btnRefresh.setOnClickListener(v -> webView.reload());

        // Custom video streaming optimizations
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Set high performing user agent according to Desktop Mode preference
        android.content.SharedPreferences prefs = android.preference.PreferenceManager.getDefaultSharedPreferences(this);
        boolean desktopMode = prefs.getBoolean("desktop_mode_enabled", false);
        boolean vpnEnabled = prefs.getBoolean("vpn_shield_enabled", false);
        String vpnProtocol = prefs.getString("vpn_selected_protocol", "Cloudflare WARP+");
        String vpnServer = prefs.getString("vpn_selected_server", "Global Anycast (WARP Routing)");
        String vpnIp = prefs.getString("vpn_node_ip", "162.159.192.1");

        String vpnSuffix = "";
        if (vpnEnabled) {
            String sanitizedProtocol = vpnProtocol.replaceAll("[^a-zA-Z0-9+]", "-");
            String sanitizedServer = vpnServer.replaceAll("[^a-zA-Z0-9() -]", "");
            vpnSuffix = " SecureShield/3.2 (" + sanitizedProtocol + "; " + sanitizedServer + "; IP:" + vpnIp + ")";
            
            // Show premium secure streaming prompt indicating tunnel is active
            String cleanServer = vpnServer.contains(" ") ? vpnServer.substring(0, vpnServer.indexOf(" ")) : vpnServer;
            android.widget.Toast.makeText(this, "🔒 Encrypted Stream Tunnel: " + vpnProtocol + " (" + cleanServer + ") ACTIVE", android.widget.Toast.LENGTH_LONG).show();
        }

        if (desktopMode) {
            settings.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 StreamBrowser/1.0" + vpnSuffix);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);
        } else {
            String originalAgent = settings.getUserAgentString();
            settings.setUserAgentString(originalAgent + " StreamBrowser/1.0" + vpnSuffix);
        }

        // Attach strict ad blocker WebViewClient
        webView.setWebViewClient(new CustomWebViewClient());

        // Attach video acceleration WebChromeClient
        chromeClient = new CustomWebChromeClient();
        webView.setWebChromeClient(chromeClient);

        if (url != null && !url.isEmpty()) {
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://" + url;
            }
            webView.loadUrl(url);
        } else {
            webView.loadUrl("https://vimeo.com/watch");
        }
    }

    // Strict ad blocker implementation intercepting network requests
    private class CustomWebViewClient extends WebViewClient {

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            progressBar.setVisibility(View.VISIBLE);
            
            // Clean up titles shown in layout
            try {
                URI uri = new URI(url);
                String host = uri.getHost();
                if (host != null) {
                    textTitle.setText(host.replace("www.", ""));
                }
            } catch (URISyntaxException e) {
                // fall through
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            progressBar.setVisibility(View.GONE);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            String url = request.getUrl().toString();
            // Ignore target popups and blank intents that break browser flow
            if (url.startsWith("about:") || url.contains("blank")) {
                return true;
            }
            return super.shouldOverrideUrlLoading(view, request);
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            try {
                android.content.SharedPreferences prefs = android.preference.PreferenceManager.getDefaultSharedPreferences(view.getContext());
                boolean adBlockEnabled = prefs.getBoolean("ad_block_enabled", true);
                if (!adBlockEnabled) {
                    return super.shouldInterceptRequest(view, request);
                }
            } catch (Exception e) {
                // Keep default blocking on parsing issues
            }

            String urlString = request.getUrl().toString().toLowerCase();
            
            // Inspect for any matching tracking or advertisement keyword
            for (String keyword : AD_KEYWORDS) {
                if (urlString.contains(keyword)) {
                    // Instantly block by delivering an empty UTF-8 plaintext payload
                    return new WebResourceResponse(
                            "text/plain", 
                            "UTF-8", 
                            new ByteArrayInputStream("".getBytes())
                    );
                }
            }
            return super.shouldInterceptRequest(view, request);
        }
    }

    // WebChromeClient supporting full-screen video layout allocation and immersive rotation
    private class CustomWebChromeClient extends WebChromeClient {

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            progressBar.setProgress(newProgress);
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) {
                onHideCustomView();
                return;
            }

            customView = view;
            customViewCallback = callback;

            // Hide normal screen contents
            webView.setVisibility(View.GONE);
            toolbar.setVisibility(View.GONE);

            // Configure full screen display card
            fullscreenContainer.addView(customView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
            ));
            fullscreenContainer.setVisibility(View.VISIBLE);

            // Automatically rotate landscape for video theater immersive experience
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

            // Enter systemic true immersive mode
            enableImmersiveMode();
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) {
                return;
            }

            // Exit systemic true immersive mode
            disableImmersiveMode();

            // Reverse orientation settings
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

            // Clean layout bindings
            fullscreenContainer.removeView(customView);
            fullscreenContainer.setVisibility(View.GONE);
            customView = null;

            if (customViewCallback != null) {
                customViewCallback.onCustomViewHidden();
                customViewCallback = null;
            }

            // Restore normal screen controls
            webView.setVisibility(View.VISIBLE);
            toolbar.setVisibility(View.VISIBLE);
        }
    }

    private void enableImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Window window = getWindow();
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            // Deprecated path for compatibility
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }
    }

    private void disableImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Window window = getWindow();
            window.setDecorFitsSystemWindows(true);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.show(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            }
        } else {
            // Deprecated path for compatibility
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            // Gracefully escape immersive full screen video overlay first
            chromeClient.onHideCustomView();
        } else if (webView.canGoBack()) {
            // Navigate back in history
            webView.goBack();
        } else {
            // Exit activity safely
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            webView.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
