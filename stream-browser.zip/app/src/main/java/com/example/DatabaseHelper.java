package com.example;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "stream_browser.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_EXTENSIONS = "extensions";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_URL = "url";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_EXTENSIONS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT NOT NULL, " +
                COLUMN_URL + " TEXT NOT NULL)";
        db.execSQL(createTable);

        // Prepopulate with elegant streaming default tabs
        insertDefault(db, "YouTube", "https://m.youtube.com");
        insertDefault(db, "Twitch TV", "https://m.twitch.tv");
        insertDefault(db, "Vimeo", "https://vimeo.com/watch");
        insertDefault(db, "Dailymotion", "https://www.dailymotion.com");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXTENSIONS);
        onCreate(db);
    }

    private void insertDefault(SQLiteDatabase db, String name, String url) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_URL, url);
        db.insert(TABLE_EXTENSIONS, null, values);
    }

    public long addExtension(String name, String url) {
        SQLiteDatabase db = null;
        long id = -1;
        try {
            db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAME, name);
            values.put(COLUMN_URL, url);
            id = db.insert(TABLE_EXTENSIONS, null, values);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (db != null) {
                try {
                    db.close();
                } catch (Exception ignored) {}
            }
        }
        return id;
    }

    public List<Extension> getAllExtensions() {
        List<Extension> list = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = this.getReadableDatabase();
            cursor = db.query(TABLE_EXTENSIONS, null, null, null, null, null, COLUMN_ID + " DESC");

            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    int idIndex = cursor.getColumnIndex(COLUMN_ID);
                    int nameIndex = cursor.getColumnIndex(COLUMN_NAME);
                    int urlIndex = cursor.getColumnIndex(COLUMN_URL);

                    if (idIndex != -1 && nameIndex != -1 && urlIndex != -1) {
                        do {
                            long id = cursor.getLong(idIndex);
                            String name = cursor.getString(nameIndex);
                            String url = cursor.getString(urlIndex);
                            list.add(new Extension(id, name, url));
                        } while (cursor.moveToNext());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                try {
                    cursor.close();
                } catch (Exception ignored) {}
            }
            if (db != null) {
                try {
                    db.close();
                } catch (Exception ignored) {}
            }
        }
        return list;
    }

    public void deleteExtension(long id) {
        SQLiteDatabase db = null;
        try {
            db = this.getWritableDatabase();
            db.delete(TABLE_EXTENSIONS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (db != null) {
                try {
                    db.close();
                } catch (Exception ignored) {}
            }
        }
    }
}
